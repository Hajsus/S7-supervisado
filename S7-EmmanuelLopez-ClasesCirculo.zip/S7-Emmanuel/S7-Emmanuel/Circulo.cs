﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.Intrinsics.Arm;
using System.Text;
using System.Threading.Tasks;

namespace S7_Emmanuel
{
    public class Circulo
    {

        double pi = Math.PI;
     

        private double radio;

        public Circulo(double Radio)
        {

            radio = Radio;
           
        }
        private double obtenerPerimetro()
        {
       
            return 2 * radio * pi;

        }
        private double obtenerArea()
        {
            double potencia = Math.Pow(radio, 2);
            return pi * potencia;
        }
        private double obtenerVolumen()
        {
            double potencia = Math.Pow(radio, 3);
            return (4 * pi * potencia) / (3);
        }

        public void CalcularGeometria(ref double Perimetro,ref double Area, ref double Volumen)
        {
            Perimetro = obtenerPerimetro();
            Area = obtenerArea();
            Volumen = obtenerVolumen();
        }
    }
}

